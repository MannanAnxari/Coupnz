module.exports = {
    APP_URL: "https://creativeitsols.com/system/public/",
    APP_KEY: "app_oKzcxb5FK7e0KRwMPANEGRuqjSh40JrMSgbyTyAN",
    DEFAULT_TITLE: "More Coupon Codes",
    DEFAULT_DESC: "More Coupon Codes",
    CONTAINER_TYPE: "wisde",
    FOOTER_ABOUT: "Discountss Co is the website where you can find latest and verified coupons and promotion codes. Redeem and save now! Big Discounts. Simple Search. Get Code. Big Discount. Always Sale. The Best Price. Paste Code at Checkout. ALmost 5000+ Stores. Redeem Code Online.",
}